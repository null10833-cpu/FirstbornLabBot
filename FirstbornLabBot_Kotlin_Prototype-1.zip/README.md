# Firstborn Lab Bot — Android starter prototype

This is a starter Android Studio project, not yet a working game-playing bot.

## Current prototype
- Kotlin Android app
- Target-list UI (placeholder names based on the supplied screenshot)
- Overlay permission flow
- Floating Start/Stop button

## Not implemented yet
- Screenshot capture / MediaProjection consent flow
- Item image template selection and matching
- Accessibility-based taps
- Lock-state verification
- Update/mix workflow and resource limits

Those are deliberately not enabled until the screen coordinates and exact button transitions are verified. Blind repeated taps could spend resources or lock the wrong item.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build APK(s).
For an installable APK, use Build > Build Bundle(s) / APK(s) > Build APK(s).

## Next implementation step
Add a user-approved MediaProjection capture flow and let the user crop each target item from a screenshot. Then validate detection on still screenshots before enabling any tap automation.
