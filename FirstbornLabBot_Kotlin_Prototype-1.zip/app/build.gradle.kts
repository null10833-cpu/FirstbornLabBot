plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.firstbornbot"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.firstbornbot"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
