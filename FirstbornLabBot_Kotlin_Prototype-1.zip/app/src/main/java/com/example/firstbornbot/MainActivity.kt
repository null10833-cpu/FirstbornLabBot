package com.example.firstbornbot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val selected = linkedSetOf<String>()
    private val itemNames = listOf(
        "Синий механический артефакт",
        "Свиток",
        "Каменная плита",
        "Фиолетовый артефакт",
        "Белый механический артефакт",
        "Слиток",
        "Деревянная доска",
        "Золотой механизм",
        "Цветы",
        "Бревно"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }
        page.addView(TextView(this).apply {
            text = "Firstborn Lab Bot — прототип"
            textSize = 22f
        })
        page.addView(TextView(this).apply {
            text = "Отметь целевые предметы. Пока это список-заготовка: следующим этапом подключим выбор эталонных изображений со скриншотов."
            textSize = 15f
            setPadding(0, 12, 0, 16)
        })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        itemNames.forEach { name ->
            val cb = CheckBox(this).apply {
                text = name
                textSize = 17f
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(name) else selected.remove(name)
                }
            }
            list.addView(cb)
        }
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(Button(this).apply {
            text = "Включить плавающую кнопку"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName"))
                    )
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        })
        page.addView(Button(this).apply {
            text = "Показать выбранные предметы"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Цели (${selected.size})")
                    .setMessage(if (selected.isEmpty()) "Пока ничего не выбрано" else selected.joinToString("\n"))
                    .setPositiveButton("OK", null)
                    .show()
            }
        })
        setContentView(page)
    }
}
