package com.example.firstbornbot

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var button: Button? = null
    private var running = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        button = Button(this).apply {
            text = "▶ БОТ"
            setOnClickListener {
                running = !running
                text = if (running) "■ СТОП" else "▶ БОТ"
                Toast.makeText(
                    this@OverlayService,
                    if (running) "Прототип включён: автоматические действия пока не подключены"
                    else "Бот остановлен",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 260
        }
        wm.addView(button, params)
    }

    override fun onDestroy() {
        button?.let { wm.removeView(it) }
        button = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
